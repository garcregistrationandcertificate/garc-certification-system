// Supabase client and synchronization helpers
const garcSB = (window.supabase && window.SUPABASE_URL && window.SUPABASE_KEY)
  ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_KEY) : null;
let garcCloudReady=false;
async function garcLoadPublicBrand(){
  if(!garcSB)return false;
  try{
    const {data,error}=await garcSB.from('app_settings').select('value').eq('key','certificate_brand').maybeSingle();
    if(error)throw error;
    if(data&&data.value&&typeof data.value==='object'){brand={...brand,...data.value};localStorage.setItem('ge_brand',JSON.stringify(brand));return true;}
  }catch(err){console.warn('GARC branding cloud load:',err);}
  return false;
}
async function garcInitCloud(){
  if(!garcSB)return;
  try{
    await garcLoadPublicBrand();
    const {data:evRows,error:evErr}=await garcSB.from('events').select('id,payload');
    if(evErr) throw evErr;
    if(evRows && evRows.length){ events=evRows.map(x=>x.payload).filter(Boolean); localStorage.setItem('ge_events',JSON.stringify(events)); }
    if((await garcSB.auth.getSession()).data.session){
      const {data:regRows,error:regErr}=await garcSB.from('registrations').select('registration_code,payload');
      if(!regErr && regRows){ regs=regRows.map(x=>x.payload).filter(Boolean); localStorage.setItem('ge_regs',JSON.stringify(regs)); }
    }
    garcCloudReady=true; renderEvents(); fillSelect(); if(adminLogged)renderRegs();
  }catch(err){console.error('GARC cloud load:',err);}
}
async function garcSaveCloud(){
  if(!garcSB)return;
  try{
    const session=(await garcSB.auth.getSession()).data.session;
    // Public event records are synced after admin sign-in only.
    if(session){
      const ev=events.map(e=>({id:Number(e.id),payload:e}));
      if(ev.length) await garcSB.from('events').upsert(ev,{onConflict:'id'});
      const rr=regs.map(r=>({registration_code:String(r.id),payload:r}));
      if(rr.length) await garcSB.from('registrations').upsert(rr,{onConflict:'registration_code'});
    }else{
      // Anonymous visitors can submit registrations; event sync is admin-only.
      const last=regs[regs.length-1]; if(last) await garcSB.from('registrations').insert({registration_code:String(last.id),payload:last});
    }
  }catch(err){console.error('GARC cloud save:',err);}
}

const seed=[{id:1,title:"Medicinal Plant Monograph Development Workshop",type:"Workshop",date:"2026-11-20",venue:"GARC Mysuru",deadline:"2026-11-15",capacity:100,desc:"Hands-on workshop on medicinal plant monograph development."},{id:2,title:"Techno Ayurveda — 2nd Edition",type:"Conference",date:"2026-12-05",venue:"Mysuru",deadline:"2026-11-28",capacity:250,desc:"Interdisciplinary dialogue connecting Ayurveda and technology."},{id:3,title:"Yoga & Healthy Ageing Webinar",type:"Webinar",date:"2026-12-12",venue:"Online",deadline:"2026-12-10",capacity:500,desc:"Yoga and healthy ageing."}];
let events=JSON.parse(localStorage.getItem("ge_events")||"null")||seed,regs=JSON.parse(localStorage.getItem("ge_regs")||"[]"),brand=JSON.parse(localStorage.getItem("ge_brand")||"{}");
function save(){localStorage.setItem("ge_events",JSON.stringify(events));localStorage.setItem("ge_regs",JSON.stringify(regs));garcSaveCloud();}
function show(id){document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));document.getElementById(id).classList.add("active");if(id==="register")fillSelect();if(id==="admin"){if(adminLogged){adminLoginBox.style.display="none";adminContent.style.display="block";renderRegs();loadBrand()}else{adminLoginBox.style.display="block";adminContent.style.display="none"}}window.scrollTo({top:260,behavior:"smooth"})}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderEvents(){let q=search.value.toLowerCase(),f=filter.value;let a=events.filter(e=>(e.title+" "+e.type).toLowerCase().includes(q)&&(!f||e.type===f));eventGrid.innerHTML=a.map(e=>`<article class="card"><span class="tag">${esc(e.type)}</span><h3>${esc(e.title)}</h3><p class="muted">📅 ${esc(e.date)} ${esc(e.start||"")}–${esc(e.end||"")} · 📍 ${esc(e.venue)}</p><p>${esc(e.desc)}</p><p class="muted">Deadline: ${esc(e.deadline||"Not specified")}</p><div class="actions"><button onclick="selectEvent(${e.id})">Register</button><button class="btn secondary" onclick="alert('${esc(e.title)}\\n${esc(e.desc)}')">Details</button></div></article>`).join("")||"No matching events"}
function fillSelect(){const sel=document.getElementById("regEvent");sel.innerHTML=events.map(e=>`<option value="${e.id}">${esc(e.title)} — ${esc(e.date)}</option>`).join("")}function selectEvent(id){show("register");document.getElementById("regEvent").value=id}
document.getElementById("regForm").addEventListener("submit",e=>{e.preventDefault();const get=id=>document.getElementById(id);const mobile=get("regMobile").value.trim();if(regs.some(x=>x.eventId===Number(get("regEvent").value)&&x.mobile===mobile)){get("regMsg").className="msg err";get("regMsg").textContent="This mobile number is already registered for this programme.";return;}let r={id:"GARC-"+Date.now().toString().slice(-7),eventId:Number(get("regEvent").value),name:get("regName").value.trim(),email:get("regEmail").value.trim(),mobile,institution:get("regInst").value.trim(),course:get("regCourse").value.trim()};regs.push(r);save();get("regMsg").className="msg ok";get("regMsg").innerHTML=`Registration successful! ID: <b>${esc(r.id)}</b>`;e.target.reset();fillSelect();});
eventForm.onsubmit=e=>{e.preventDefault();events.unshift({id:Date.now(),title:evTitle.value,type:evType.value,date:evDate.value,start:evStart.value,end:evEnd.value,venue:evVenue.value,deadline:evDeadline.value,capacity:+evCapacity.value||0,desc:evDesc.value});save();e.target.reset();renderEvents();adminMsg.className="msg ok";adminMsg.textContent="Event added.";};
function certificateReleaseDate(ev){if(!ev||!ev.date)return null;let release=new Date(ev.date+"T16:00:00");if(ev.end){let end=new Date(ev.date+"T"+ev.end+":00");if(!isNaN(end)&&end>release)release=end;}return release;}
function certificateIsReleased(ev){let release=certificateReleaseDate(ev);return !!release&&!isNaN(release)&&new Date()>=release;}
function findCert(){let rs=regs.filter(r=>r.mobile===certMobile.value.trim());certResult.innerHTML=rs.length?rs.map(r=>{let ev=events.find(e=>e.id===r.eventId)||{},ready=certificateIsReleased(ev),release=certificateReleaseDate(ev);return `<div class="card" style="margin-top:12px"><h3>${esc(ev.title)}</h3><p>${esc(r.name)} · ${esc(r.id)}</p>${ready?`<button onclick="printCert('${r.id}')">Download certificate (PDF)</button>`:`<div class="msg" style="display:block">Certificate is locked until programme completion and ${release?release.toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short'}):'4:00 PM'} IST.</div>`}</div>`}).join(''):'<div class="msg err" style="display:block">No registration found for this mobile in this browser.</div>'}
async function printCert(id){await garcLoadPublicBrand();let r=regs.find(x=>x.id===id);if(!r)return;let ev=events.find(e=>e.id===r.eventId)||{};if(!certificateIsReleased(ev)){alert("Certificate download is locked until programme completion and 4:00 PM IST on programme day (or scheduled end time, if later).");return;}let w=window.open("","_blank");if(!w){alert("Allow pop-ups for this site and retry.");return}let wording=(brand.wording||"This is to certify that {NAME} has participated in {EVENT}, held on {DATE} from {START} to {END}, organised by Government Ayurveda Research Centre, Mysuru.").replaceAll("{NAME}",r.name).replaceAll("{EVENT}",ev.title||"GARC programme").replaceAll("{DATE}",ev.date||"").replaceAll("{START}",ev.start||"").replaceAll("{END}",ev.end||"");w.document.write(`<html><head><title>GARC Certificate</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:Georgia;color:#173f2e;text-align:center;padding:20px}.frame{border:8px double #bd9238;padding:25px 45px;height:90%;min-height:480px;position:relative}.top{font: bold 15px Arial;letter-spacing:1.5px;color:#245c43}.logo{max-height:75px;max-width:140px;object-fit:contain;margin-bottom:6px}.title{font-size:34px;color:#ad8124;margin:20px 0}.name{font-size:32px;font-weight:bold;color:#174f36;border-bottom:1px solid #b99a55;display:inline-block;padding:8px 60px}.desc{font-size:19px;line-height:1.8;max-width:850px;margin:20px auto}.sign{max-height:65px;max-width:180px;object-fit:contain;display:block;margin:0 auto -5px}.bottom{display:flex;justify-content:space-between;margin-top:35px;font:14px Arial}.issuer{font-weight:bold}.foot{font:11px Arial;color:#777;margin-top:20px}@media print{body{padding:0}}#adminLoginBox label{display:block;font-size:13px;font-weight:bold;margin-bottom:5px}#adminLoginBox input{margin-bottom:8px}.headbrand{display:flex;align-items:center;gap:20px;flex-wrap:wrap}.institution-logos{display:block;width:100%;max-width:700px;height:110px;object-fit:contain;object-position:left center;background:#fff;border-radius:8px;padding:4px;flex:0 1 700px}.headbrand h1{letter-spacing:-.5px}.headbrand .brand{font-size:12px}
</style></head><body><div class="frame">${brand.logo?`<img class="logo" src="${brand.logo}">`:""}<div class="top">${esc(brand.line1||"GOVERNMENT OF KARNATAKA")}<br>${esc(brand.line2||"DEPARTMENT OF AYUSH")}<br>${esc(brand.line3||"GOVERNMENT AYURVEDA RESEARCH CENTRE, MYSURU")}</div><div class="title">${esc(brand.heading||"CERTIFICATE OF PARTICIPATION")}</div><p>This certificate is proudly presented to</p><div class="name">${esc(r.name)}</div><div class="desc">${esc(wording)}</div><div class="bottom"><div>Certificate ID: ${esc(r.id)}</div><div class="issuer">${brand.signature?`<img class="sign" src="${brand.signature}">`:""}${esc(brand.issuer||"Authorised Signatory")}<br>${esc(brand.role||"")}</div></div><div class="foot">Government Ayurveda Research Centre, Mysuru · Department of AYUSH, Government of Karnataka</div></div><script>window.onload=async()=>{const imgs=[...document.images];await Promise.all(imgs.map(img=>img.complete&&img.naturalWidth?Promise.resolve():new Promise(resolve=>{img.onload=resolve;img.onerror=resolve;})));setTimeout(()=>window.print(),400);};<\/script></body></html>`);w.document.close()}
function fileData(id){return new Promise(res=>{let f=document.getElementById(id).files[0];if(!f)return res("");let rd=new FileReader();rd.onload=()=>res(rd.result);rd.readAsDataURL(f)})}
async function saveBrand(){brand={line1:brandLine1.value,line2:brandLine2.value,line3:brandLine3.value,heading:certHeading.value,issuer:issuerName.value,role:issuerRole.value,wording:certWording.value,logo:await fileData("logoFile")||brand.logo||"",signature:await fileData("signFile")||brand.signature||""};localStorage.setItem("ge_brand",JSON.stringify(brand));if(garcSB){try{const {error}=await garcSB.from("app_settings").upsert({key:"certificate_brand",value:brand,updated_at:new Date().toISOString()},{onConflict:"key"});if(error)throw error;adminMsg.textContent="Branding saved to Supabase. Logo and signature are available across devices.";}catch(err){adminMsg.textContent="Saved locally; cloud save failed: "+(err.message||err);}}else adminMsg.textContent="Branding saved locally only (Supabase unavailable).";adminMsg.className="msg ok";renderPreview()}
function loadBrand(){for(let [id,key] of [["brandLine1","line1"],["brandLine2","line2"],["brandLine3","line3"],["certHeading","heading"],["issuerName","issuer"],["issuerRole","role"],["certWording","wording"]])if(brand[key])document.getElementById(id).value=brand[key];renderPreview()}
function renderPreview(){brandPreview.innerHTML=(brand.logo?`<img src="${brand.logo}">`:"<small>Logo not uploaded</small>")+"<br>"+esc(brand.line1||brandLine1.value)+"<br>"+esc(brand.line2||brandLine2.value)+"<br><b>"+esc(brand.line3||brandLine3.value)+"</b>"+(brand.signature?`<img src="${brand.signature}">`:"<br><small>Signature not uploaded</small>")+"<small>"+esc(brand.issuer||issuerName.value)+" · "+esc(brand.role||issuerRole.value)+"</small>"}
function clearBrand(){if(confirm("Remove saved logo and signature?")){brand.logo="";brand.signature="";localStorage.setItem("ge_brand",JSON.stringify(brand));logoFile.value="";signFile.value="";renderPreview();}}
function renderRegs(){manageEvents.innerHTML=events.map(e=>`<div class="card" style="margin:10px 0"><b>${esc(e.title)}</b><span class="muted"> · ${esc(e.date)} ${esc(e.start||"")}–${esc(e.end||"")}</span><button style="float:right" onclick="editEvent(${e.id})">Edit</button></div>`).join("");regTable.innerHTML=regs.length?`<table><tr><th>Name</th><th>Event</th><th>Mobile</th><th>ID</th></tr>${regs.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc((events.find(e=>e.id===r.eventId)||{}).title)}</td><td>${esc(r.mobile)}</td><td>${esc(r.id)}</td></tr>`).join("")}</table>`:"No registrations yet"}
function editEvent(id){let e=events.find(x=>x.id===id);if(!e)return;let title=prompt("Event title:",e.title);if(title===null)return;let date=prompt("Event date (YYYY-MM-DD):",e.date);if(date===null)return;let start=prompt("Start time (HH:MM):",e.start||"");if(start===null)return;let end=prompt("End time (HH:MM):",e.end||"");if(end===null)return;let venue=prompt("Venue:",e.venue||"");if(venue===null)return;let desc=prompt("Description:",e.desc||"");if(desc===null)return;Object.assign(e,{title,date,start,end,venue,desc});save();renderEvents();renderRegs();alert("Event updated.");}
function exportCSV(){let rows=[["ID","Name","Email","Mobile","Institution","Event"],...regs.map(r=>[r.id,r.name,r.email,r.mobile,r.institution,(events.find(e=>e.id===r.eventId)||{}).title])];let csv=rows.map(x=>x.map(v=>'"'+String(v||"").replace(/"/g,'""')+'"').join(",")).join("\\r\\n"),a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="garc-registrations.csv";a.click()}
function resetDemo(){if(confirm("Reset demo events and registrations?")){events=seed;regs=[];save();renderEvents();renderRegs()}}

const ADMIN_USER="Drshenoy",ADMIN_PASS="Garc@636322";
let adminLogged=false;
document.getElementById("loginForm").onsubmit=async e=>{
 e.preventDefault();
 const u=document.getElementById("loginUser").value.trim(),p=document.getElementById("loginPass").value;
 const m=document.getElementById("loginMsg");
 if(!garcSB){m.className="msg err";m.textContent="Configure Supabase in supabase-config.js first.";return;}
 const {data,error}=await garcSB.auth.signInWithPassword({email:u,password:p});
 if(!error&&data.user){adminLogged=true;document.getElementById("adminLoginBox").style.display="none";document.getElementById("adminContent").style.display="block";m.className="msg";loadBrand();renderRegs();await garcInitCloud();}
 else{m.className="msg err";m.textContent=error?.message||"Login failed. Check email/password and Supabase Auth user."}
};
function logoutAdmin(){adminLogged=false;document.getElementById("adminContent").style.display="none";document.getElementById("adminLoginBox").style.display="block";document.getElementById("loginPass").value="";document.getElementById("loginMsg").className="msg";}

renderEvents();fillSelect();garcInitCloud();